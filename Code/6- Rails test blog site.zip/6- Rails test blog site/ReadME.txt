Start rails server in blogger folder

navigate to localhost:3000